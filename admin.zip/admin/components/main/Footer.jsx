export default function Footer() {
  return (
    <footer className="bg-dark text-white p-3 text-center">
      <small>© 2023 Afrikanischer Tanz. All rights reserved.</small>
    </footer>
  );
}
